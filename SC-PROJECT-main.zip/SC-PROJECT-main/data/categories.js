const categories = [
  { name: "Software Development" },
  { name: "Machine Learning" },
  { name: "Network and Security" },
  { name: "Artificial Intelligence" },
  { name: "Computer Vision" },
  { name: "Blockchain Technology" },
  { name: "Internet of Things (IoT)" },
  { name: "Cloud Computing" },
  { name: "Cybersecurity" },
];

module.exports = categories;
